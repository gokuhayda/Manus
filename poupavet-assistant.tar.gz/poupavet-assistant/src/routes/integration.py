from flask import Blueprint, request, jsonify
import requests
import json
from datetime import datetime

integration_bp = Blueprint('integration', __name__)

# Configurações para integração com n8n
N8N_WEBHOOK_URL = "https://your-n8n-instance.com/webhook/poupavet-agendamento"
N8N_API_KEY = "your-api-key-here"

class IntegracaoExterna:
    def __init__(self):
        self.n8n_url = N8N_WEBHOOK_URL
        self.api_key = N8N_API_KEY
    
    def enviar_agendamento_n8n(self, dados_agendamento):
        """Envia dados de agendamento para o n8n"""
        try:
            # Adicionar campo 'agenda' automaticamente
            dados_completos = dados_agendamento.copy()
            dados_completos['agenda'] = self._gerar_id_agenda()
            dados_completos['timestamp'] = datetime.now().isoformat()
            dados_completos['origem'] = 'assistente_virtual'
            
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {self.api_key}'
            }
            
            response = requests.post(
                self.n8n_url,
                json=dados_completos,
                headers=headers,
                timeout=10
            )
            
            if response.status_code == 200:
                return {
                    "sucesso": True,
                    "mensagem": "Agendamento enviado com sucesso",
                    "id_agenda": dados_completos['agenda']
                }
            else:
                return {
                    "sucesso": False,
                    "mensagem": f"Erro no envio: {response.status_code}",
                    "detalhes": response.text
                }
                
        except requests.exceptions.RequestException as e:
            return {
                "sucesso": False,
                "mensagem": "Erro de conexão com n8n",
                "detalhes": str(e)
            }
        except Exception as e:
            return {
                "sucesso": False,
                "mensagem": "Erro interno",
                "detalhes": str(e)
            }
    
    def _gerar_id_agenda(self):
        """Gera um ID único para o agendamento"""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        return f"AGD{timestamp}"
    
    def verificar_disponibilidade(self, data, hora, medico=None):
        """Verifica disponibilidade de horário (simulado)"""
        # Esta função seria integrada com um sistema de calendário real
        # Por enquanto, simula verificação de conflitos
        
        # Horários ocupados simulados
        horarios_ocupados = [
            {"data": "2025-01-20", "hora": "14:00", "medico": "Ana"},
            {"data": "2025-01-20", "hora": "15:00", "medico": "Carlos"},
            {"data": "2025-01-21", "hora": "09:00", "medico": "Maria"}
        ]
        
        for ocupado in horarios_ocupados:
            if (ocupado["data"] == data and 
                ocupado["hora"] == hora and 
                (medico is None or ocupado["medico"] == medico)):
                return {
                    "disponivel": False,
                    "motivo": "Horário já ocupado",
                    "alternativas": self._sugerir_horarios_alternativos(data, hora)
                }
        
        return {
            "disponivel": True,
            "confirmado": True
        }
    
    def _sugerir_horarios_alternativos(self, data, hora):
        """Sugere horários alternativos"""
        # Lógica simplificada para sugerir horários
        from datetime import datetime, timedelta
        
        base_datetime = datetime.strptime(f"{data} {hora}", "%Y-%m-%d %H:%M")
        alternativas = []
        
        for i in range(1, 4):  # 3 alternativas
            nova_hora = base_datetime + timedelta(hours=i)
            alternativas.append({
                "data": nova_hora.strftime("%Y-%m-%d"),
                "hora": nova_hora.strftime("%H:%M"),
                "disponivel": True
            })
        
        return alternativas
    
    def integrar_whatsapp(self, dados_resposta, numero_telefone):
        """Integra com API do WhatsApp para envio de mensagens"""
        # Esta função seria integrada com a API do WhatsApp Business
        # Por enquanto, simula o envio
        
        try:
            # Simular envio para WhatsApp
            mensagem_formatada = self._formatar_mensagem_whatsapp(dados_resposta)
            
            # Aqui seria feita a integração real com a API do WhatsApp
            # Por exemplo: Evolution API, Baileys, etc.
            
            return {
                "sucesso": True,
                "mensagem": "Mensagem enviada para WhatsApp",
                "numero": numero_telefone,
                "conteudo": mensagem_formatada
            }
            
        except Exception as e:
            return {
                "sucesso": False,
                "mensagem": "Erro no envio para WhatsApp",
                "detalhes": str(e)
            }
    
    def _formatar_mensagem_whatsapp(self, dados_resposta):
        """Formata mensagem para envio via WhatsApp"""
        if dados_resposta.get("json_response", {}).get("intencao") == "agendamento":
            agendamento = dados_resposta["json_response"]
            return f"""
✅ *Agendamento Confirmado - PoupaVet*

🐾 *Pet:* {agendamento.get('pet', 'N/A')}
👤 *Tutor:* {agendamento.get('tutor', 'N/A')}
🩺 *Serviço:* {agendamento.get('servico', 'N/A')}
📅 *Data:* {agendamento.get('data', 'N/A')}
⏰ *Horário:* {agendamento.get('hora', 'N/A')}
👨‍⚕️ *Médico:* {agendamento.get('medico', 'Dr. Ana Padrão')}

📍 *Local:* Rua Volans, 740 - Jardim Satélite, São José dos Campos/SP

Qualquer dúvida, entre em contato conosco! 🐾💚
            """.strip()
        
        elif dados_resposta.get("json_response", {}).get("intencao") == "emergencia":
            return """
🚨 *EMERGÊNCIA VETERINÁRIA* 🚨

Sua solicitação de emergência foi recebida!
Nossa equipe de plantão será notificada imediatamente.

📞 *Contato direto:* (12) 99999-9999
📍 *Endereço:* Rua Volans, 740 - Jardim Satélite, São José dos Campos/SP

Aguarde nosso contato! 🆘🐾
            """.strip()
        
        else:
            return dados_resposta.get("message", "Mensagem da PoupaVet")

# Instância global da integração
integracao = IntegracaoExterna()

@integration_bp.route('/webhook/n8n', methods=['POST'])
def webhook_n8n():
    """Webhook para receber dados do n8n"""
    try:
        data = request.get_json()
        
        # Processar dados recebidos do n8n
        # Aqui você pode implementar lógica para processar
        # confirmações de agendamento, atualizações, etc.
        
        return jsonify({
            "status": "success",
            "message": "Dados recebidos com sucesso",
            "timestamp": datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@integration_bp.route('/enviar-agendamento', methods=['POST'])
def enviar_agendamento():
    """Endpoint para enviar agendamento para n8n"""
    try:
        data = request.get_json()
        resultado = integracao.enviar_agendamento_n8n(data)
        return jsonify(resultado)
    
    except Exception as e:
        return jsonify({
            "sucesso": False,
            "mensagem": "Erro interno",
            "detalhes": str(e)
        }), 500

@integration_bp.route('/verificar-disponibilidade', methods=['POST'])
def verificar_disponibilidade():
    """Endpoint para verificar disponibilidade de horários"""
    try:
        data = request.get_json()
        data_agendamento = data.get('data')
        hora_agendamento = data.get('hora')
        medico = data.get('medico')
        
        resultado = integracao.verificar_disponibilidade(
            data_agendamento, 
            hora_agendamento, 
            medico
        )
        
        return jsonify(resultado)
    
    except Exception as e:
        return jsonify({
            "disponivel": False,
            "erro": str(e)
        }), 500

@integration_bp.route('/enviar-whatsapp', methods=['POST'])
def enviar_whatsapp():
    """Endpoint para enviar mensagem via WhatsApp"""
    try:
        data = request.get_json()
        dados_resposta = data.get('resposta')
        numero_telefone = data.get('numero')
        
        resultado = integracao.integrar_whatsapp(dados_resposta, numero_telefone)
        return jsonify(resultado)
    
    except Exception as e:
        return jsonify({
            "sucesso": False,
            "mensagem": "Erro no envio",
            "detalhes": str(e)
        }), 500

@integration_bp.route('/status', methods=['GET'])
def status_integracoes():
    """Endpoint para verificar status das integrações"""
    return jsonify({
        "n8n": {
            "configurado": bool(N8N_WEBHOOK_URL and N8N_API_KEY),
            "url": N8N_WEBHOOK_URL if N8N_WEBHOOK_URL else "Não configurado"
        },
        "whatsapp": {
            "disponivel": True,
            "status": "Simulado"
        },
        "calendario": {
            "disponivel": True,
            "status": "Simulado"
        }
    })

