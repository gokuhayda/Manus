from flask import Blueprint, request, jsonify
import json
import re
from datetime import datetime, timedelta

assistant_bp = Blueprint('assistant', __name__)

# Base de conhecimento de preços e serviços
KNOWLEDGE_BASE = {
    "servicos": [
        {"nome": "consulta", "preco": 85.00, "descricao": "Consulta veterinária geral"},
        {"nome": "retorno", "preco": 0.00, "descricao": "Retorno de consulta"},
        {"nome": "vacina v10", "preco": 120.00, "descricao": "Vacina múltipla para cães"},
        {"nome": "vacina antirrabica", "preco": 80.00, "descricao": "Vacina contra raiva"},
        {"nome": "cirurgia", "preco": 500.00, "descricao": "Cirurgia veterinária"},
        {"nome": "exame", "preco": 150.00, "descricao": "Exames diversos"},
        {"nome": "ultrassom", "preco": 200.00, "descricao": "Exame de ultrassom"},
        {"nome": "hemograma", "preco": 80.00, "descricao": "Exame de sangue completo"},
        {"nome": "radiografia", "preco": 120.00, "descricao": "Exame radiográfico"}
    ]
}

# Lista de médicos disponíveis
MEDICOS = [
    {"nome": "Ana", "especialidade": "cirurgia"},
    {"nome": "Carlos", "especialidade": "cardiologia"},
    {"nome": "Maria", "especialidade": "dermatologia"},
    {"nome": "João", "especialidade": "oftalmologia"}
]

class AssistentePoupaVet:
    def __init__(self):
        self.knowledge_base = KNOWLEDGE_BASE
        self.medicos = MEDICOS
    
    def processar_mensagem(self, mensagem, contexto=None):
        """Processa a mensagem do usuário e retorna a resposta apropriada"""
        mensagem = mensagem.lower().strip()
        
        # Detectar emergência
        if self._detectar_emergencia(mensagem):
            return self._resposta_emergencia()
        
        # Detectar intenção de agendamento
        if self._detectar_agendamento(mensagem):
            return self._processar_agendamento(mensagem, contexto)
        
        # Detectar consulta de preços
        if self._detectar_consulta_preco(mensagem):
            return self._processar_consulta_preco(mensagem)
        
        # Detectar solicitação de médicos
        if self._detectar_solicitacao_medicos(mensagem):
            return self._listar_medicos()
        
        # Resposta padrão para outras consultas
        return self._resposta_padrao()
    
    def _detectar_emergencia(self, mensagem):
        """Detecta sinais de emergência na mensagem"""
        palavras_emergencia = [
            "urgente", "emergencia", "sangrando", "atropelado", 
            "convulsionando", "não está respirando", "morreu", 
            "desmaiou", "socorro", "ajuda"
        ]
        return any(palavra in mensagem for palavra in palavras_emergencia)
    
    def _resposta_emergencia(self):
        """Retorna resposta para casos de emergência"""
        return {
            "message": "🚨 Entendi, parece ser uma emergência! Já estou alertando a equipe. Por favor, aguarde um instante. 🆘🐾",
            "json_response": {
                "intencao": "emergencia",
                "redirecionar": "humano"
            }
        }
    
    def _detectar_agendamento(self, mensagem):
        """Detecta intenção de agendamento"""
        palavras_agendamento = [
            "agendar", "marcar", "consulta", "horário", "data", 
            "quero", "preciso", "gostaria", "pode marcar"
        ]
        return any(palavra in mensagem for palavra in palavras_agendamento)
    
    def _processar_agendamento(self, mensagem, contexto):
        """Processa solicitação de agendamento"""
        dados_agendamento = self._extrair_dados_agendamento(mensagem, contexto)
        
        # Verificar se todos os dados obrigatórios estão presentes
        campos_obrigatorios = ["tutor", "pet", "especie", "servico", "data", "hora"]
        dados_faltantes = [campo for campo in campos_obrigatorios if not dados_agendamento.get(campo)]
        
        if dados_faltantes:
            return self._solicitar_dados_faltantes(dados_faltantes, dados_agendamento)
        
        # Se não tem médico nem especialidade, mostrar botão para listar médicos
        if not dados_agendamento.get("medico") and not dados_agendamento.get("especialidade"):
            return {
                "json_response": {
                    "intencao": "botao_list_medico",
                    "message": "Você tem preferência por algum médico ou médica da nossa equipe? 😊 Se preferir, selecione abaixo:"
                }
            }
        
        # Gerar JSON de agendamento
        return self._gerar_json_agendamento(dados_agendamento)
    
    def _extrair_dados_agendamento(self, mensagem, contexto):
        """Extrai dados de agendamento da mensagem"""
        dados = {}
        
        # Extrair nome do pet (palavras após "para o/a", "do/da", etc.)
        pet_match = re.search(r'(?:para o|para a|do|da|com o|com a)\s+(\w+)', mensagem)
        if pet_match:
            dados["pet"] = pet_match.group(1).title()
        
        # Extrair serviço
        for servico in self.knowledge_base["servicos"]:
            if servico["nome"] in mensagem:
                dados["servico"] = servico["nome"]
                break
        
        # Extrair médico
        for medico in self.medicos:
            if medico["nome"].lower() in mensagem:
                dados["medico"] = medico["nome"]
                dados["especialidade"] = medico["especialidade"]
                break
        
        # Extrair especialidade
        especialidades = ["cirurgia", "cardiologia", "dermatologia", "oftalmologia"]
        for esp in especialidades:
            if esp in mensagem:
                dados["especialidade"] = esp
                break
        
        # Extrair data e hora (simplificado)
        if "amanhã" in mensagem:
            dados["data"] = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
        elif "hoje" in mensagem:
            dados["data"] = datetime.now().strftime("%Y-%m-%d")
        
        # Extrair hora
        hora_match = re.search(r'(\d{1,2}):?(\d{0,2})\s*h?', mensagem)
        if hora_match:
            hora = hora_match.group(1)
            minuto = hora_match.group(2) or "00"
            dados["hora"] = f"{hora.zfill(2)}:{minuto.zfill(2)}"
        
        # Dados padrão se não especificados
        if contexto:
            dados["tutor"] = contexto.get("nome", "Cliente")
        else:
            dados["tutor"] = "Cliente"
        
        if not dados.get("especie"):
            dados["especie"] = "cão"  # padrão
        
        return dados
    
    def _solicitar_dados_faltantes(self, dados_faltantes, dados_parciais):
        """Solicita dados faltantes para o agendamento"""
        if "especie" in dados_faltantes:
            return {
                "message": "Qual é a espécie do seu pet? 🐾",
                "buttonList": {
                    "buttons": [
                        {"id": "cao", "label": "🐶 Cão"},
                        {"id": "gato", "label": "🐱 Gato"},
                        {"id": "coelho", "label": "🐇 Coelho"},
                        {"id": "ave", "label": "🦜 Ave"},
                        {"id": "roedor", "label": "🐹 Roedor"},
                        {"id": "reptil", "label": "🦎 Réptil"},
                        {"id": "silvestre", "label": "🦔 Silvestre"},
                        {"id": "outra", "label": "🐾 Outra espécie"}
                    ]
                }
            }
        
        if "servico" in dados_faltantes:
            return {
                "message": "Que tipo de atendimento você precisa? 🩺",
                "optionList": {
                    "title": "Como deseja atendimento?",
                    "buttonLabel": "Escolher forma",
                    "options": [
                        {"id": "1", "title": "Consulta", "description": "Consulta veterinária geral"},
                        {"id": "2", "title": "Retorno", "description": "Acompanhamento com o mesmo vet"},
                        {"id": "3", "title": "Vacina", "description": "Vacinação do pet"},
                        {"id": "4", "title": "Exame", "description": "Exames diversos"},
                        {"id": "5", "title": "Cirurgia", "description": "Procedimento cirúrgico"}
                    ]
                }
            }
        
        # Redirecionar para humano se dados críticos estão faltando
        return {
            "message": "Para finalizar o agendamento, preciso de mais algumas informações. Vou te conectar com nossa equipe! 🐾😊",
            "json_response": {
                "intencao": "outro",
                "redirecionar": "humano"
            }
        }
    
    def _gerar_json_agendamento(self, dados):
        """Gera o JSON final de agendamento"""
        json_agendamento = {
            "intencao": "agendamento",
            "tutor": dados["tutor"],
            "pet": dados["pet"],
            "especie": dados["especie"],
            "servico": dados["servico"],
            "data": dados["data"],
            "hora": dados["hora"]
        }
        
        # Adicionar campos opcionais se presentes
        if dados.get("medico"):
            json_agendamento["medico"] = dados["medico"]
        else:
            json_agendamento["medico"] = "Dr. Ana Padrão"
        
        if dados.get("especialidade"):
            json_agendamento["especialidade"] = dados["especialidade"]
        
        # Gerar detalhamento
        detalhamento = f"✅ {dados['servico'].title()} do {dados['pet']} confirmado para {dados['data']} às {dados['hora']} 🐾💖"
        json_agendamento["detalhamento"] = detalhamento
        
        return {
            "json_response": json_agendamento
        }
    
    def _detectar_consulta_preco(self, mensagem):
        """Detecta consulta sobre preços"""
        palavras_preco = [
            "preço", "valor", "custa", "quanto", "custo", 
            "tabela", "valores", "preços"
        ]
        return any(palavra in mensagem for palavra in palavras_preco)
    
    def _processar_consulta_preco(self, mensagem):
        """Processa consulta sobre preços"""
        # Buscar serviço específico na mensagem
        for servico in self.knowledge_base["servicos"]:
            if servico["nome"] in mensagem:
                return {
                    "message": f"A {servico['nome']} na PoupaVet custa R$ {servico['preco']:.2f}. {servico['descricao']}. Posso ajudar com o agendamento? 🐾"
                }
        
        # Se não encontrou serviço específico, mostrar opções
        return {
            "message": "Sobre qual serviço você gostaria de saber o valor? 💰",
            "optionList": {
                "title": "Dúvidas de valores?",
                "buttonLabel": "Selecione o tipo",
                "options": [
                    {"id": "1", "title": "Consulta", "description": "Valores e modalidades"},
                    {"id": "2", "title": "Vacinas", "description": "Tabela atualizada"},
                    {"id": "3", "title": "Exames", "description": "Principais exames"},
                    {"id": "4", "title": "Cirurgias", "description": "Custos estimados por tipo"}
                ]
            }
        }
    
    def _detectar_solicitacao_medicos(self, mensagem):
        """Detecta solicitação para listar médicos"""
        palavras_medicos = [
            "médico", "veterinário", "doutor", "doutora", 
            "profissional", "especialista"
        ]
        return any(palavra in mensagem for palavra in palavras_medicos)
    
    def _listar_medicos(self):
        """Lista os médicos disponíveis"""
        return {
            "message": "Nossos veterinários disponíveis: 👩‍⚕️👨‍⚕️",
            "optionList": {
                "title": "Escolha o veterinário",
                "buttonLabel": "Selecionar médico",
                "options": [
                    {"id": str(i+1), "title": f"Dr(a). {medico['nome']}", "description": f"Especialista em {medico['especialidade']}"}
                    for i, medico in enumerate(self.medicos)
                ]
            }
        }
    
    def _resposta_padrao(self):
        """Resposta padrão para mensagens não categorizadas"""
        return {
            "message": "Olá! 👋 Sou a assistente virtual da PoupaVet. Como posso ajudar você hoje?",
            "buttonList": {
                "buttons": [
                    {"id": "1", "label": "Agendar Consulta"},
                    {"id": "2", "label": "Ver Preços"},
                    {"id": "3", "label": "Emergência"},
                    {"id": "4", "label": "Falar com Atendente"}
                ]
            }
        }

# Instância global da assistente
assistente = AssistentePoupaVet()

@assistant_bp.route('/chat', methods=['POST'])
def chat():
    """Endpoint principal para processar mensagens"""
    try:
        data = request.get_json()
        mensagem = data.get('mensagem', '')
        contexto = data.get('contexto', {})
        
        if not mensagem:
            return jsonify({"error": "Mensagem não fornecida"}), 400
        
        resposta = assistente.processar_mensagem(mensagem, contexto)
        return jsonify(resposta)
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@assistant_bp.route('/servicos', methods=['GET'])
def listar_servicos():
    """Endpoint para listar todos os serviços disponíveis"""
    return jsonify(KNOWLEDGE_BASE)

@assistant_bp.route('/medicos', methods=['GET'])
def listar_medicos_api():
    """Endpoint para listar todos os médicos disponíveis"""
    return jsonify({"medicos": MEDICOS})

@assistant_bp.route('/health', methods=['GET'])
def health_check():
    """Endpoint de verificação de saúde da API"""
    return jsonify({"status": "ok", "message": "Assistente PoupaVet funcionando!"})

